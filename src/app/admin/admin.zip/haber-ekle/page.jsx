"use client";
import { Button, Spin, Form, message, Input, Select } from "antd";
import { token, user } from "../GetUserData";
import { LoadingOutlined } from '@ant-design/icons';
import { useRouter } from "next/navigation";
import 'react-quill-new/dist/quill.snow.css';
import { useEffect, useState } from "react";
import ReactQuill from 'react-quill-new';
import {Image} from "../Image/Image";
import AdminLayout from "../page";

function AddNew() {
    const [messageApi, contextHolder] = message.useMessage();
    const [openImage, setOpenImage] = useState(false);
    const apiURL = process.env.NEXT_PUBLIC_API_URL;
    const [loading, setLoading] = useState(false);
    const [images, setImages] = useState("");
    const navigate = useRouter();
    const [form] = Form.useForm();



    const handleImageSelection = (images) => {
        setImages(images);
        setOpenImage(false)
    };


    const onFinish = async (values) => {
        if(images != ""){
            const formData = {
                newAuthor: user._id,
                newTitle: values.newTitle,
                newImage: images,
                newCategory: values.newCategory,
                newContent: values.newContent,
                newLink: values.newLink,
                newSEO: {
                    title: values.metaTitle,
                    description: values.metaDescription,
                    keywords: values.metaKeywords,
                }
            }
            try {
                setLoading(true);
                const response = await fetch(`${apiURL}/api/news`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(formData),
                });
                const data = await response.json();
                if (response.ok) {
                    messageApi.success(data.message);
                    form.resetFields();
                    setImages("");
                    navigate.push('/admin/haberlerim');
                }
                else { messageApi.error(data.message); }
            }
            catch (error) {
                console.log(error);
                messageApi.error("Bir hata oluştu: " + error)
            }
            finally { setLoading(false); }
        }
        else{
            messageApi.error("Lütfen bir resim seçin.");
        }
    };

    return (
        <AdminLayout>
        <Spin spinning={loading} tip="Yükleniyor..." indicator={<LoadingOutlined spin />} size="large">
            {contextHolder}
            {openImage && <Image onClose={() => setOpenImage(false)} onImagesSelected={handleImageSelection} images={images} maxImages={1} />}
            <Form
                form={form}
                name="basic"
                layout="vertical"
                autoComplete="off"
                onFinish={onFinish}
            >
                <div className="flex flex-col sm:gap-4">

                    <div className="flex sm:flex-row flex-col sm:gap-4">
                        <Form.Item
                            label="Başlık"
                            name="newTitle"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="Kategori"
                            name="newCategory"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Select
                                options={[
                                    { value: "Gündem", label: "Gündem" },
                                    { value: "Spor", label: "Spor" },
                                    { value: "Ekonomi", label: "Ekonomi" },
                                    { value: "Magazin", label: "Magazin" },
                                    { value: "Siyaset", label: "Siyaset" },
                                    { value: "Teknoloji", label: "Teknoloji" },
                                    { value: "Sağlık", label: "Sağlık" },
                                    { value: "Bilim", label: "Bilim" },
                                    { value: "Sanat", label: "Sanat" }
                                ]}
                            />
                        </Form.Item>
                    </div>

                    <Form.Item
                        label="İçerik"
                        name="newContent"
                        rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                        style={{ width: "100%" }}
                    >
                        <ReactQuill style={{
                            backgroundColor: "white"
                        }} />
                    </Form.Item>

                    <div className="flex sm:flex-row flex-col sm:gap-4">
                        <Form.Item
                            label="Meta Başlığı"
                            name="metaTitle"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="Meta Açıklaması"
                            name="metaDescription"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Input />
                        </Form.Item>
                    </div>

                    <div className="flex sm:flex-row flex-col sm:gap-4">
                        <Form.Item
                            label="Etiketler (Virgül ile ayırınız.)"
                            name="metaKeywords"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="Haber Bağlantısı"
                            name="newLink"
                            rules={[{ required: true, message: 'Lütfen bu alanı doldurun.' }]}
                            style={{ width: "100%" }}
                        >
                            <Input />
                        </Form.Item>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="flex flex-col gap-4 w-full">
                            <Button className="w-full" type="primary" onClick={() => setOpenImage(true)} style={{ width: "100%" }}>Resim Seç</Button>
                            {images != "" ?
                                <div style={{ width: "100%", display: "grid", gridTemplateColumns: "1fr", gap: "1rem" }}>
                                    {images.split("\n").map((img, key) => (
                                        img && <img src={apiURL + '/api/image/' + img} key={key} style={{ width: "100%" }} />
                                    ))}
                                </div>
                                :
                                <h4>Resim seçilmemiş.</h4>
                            }
                        </div>
                        <Button className="w-full" type="primary" htmlType="submit" style={{ width: "100%" }}>Kaydet</Button>
                    </div>
                </div>
            </Form>
        </Spin>
        </AdminLayout>
    )
}

export default AddNew